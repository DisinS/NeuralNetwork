﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    class Data
    {
        public static double[][] LoadIris()
        {
            string[] lines = File.ReadAllLines(@"Iris.txt");
            double[][] data = new double[lines.Length][];
            for (int i = 0; i < lines.Length; i++)
            {
                string[] tmp = lines[i].Split(',');
                data[i] = new double[tmp.Length + 2];
                for (int j = 0; j < tmp.Length - 1; j++)
                {
                    data[i][j] = Convert.ToDouble(tmp[j].Replace('.', ','));
                    if (tmp[tmp.Length - 1] == "Iris-setosa")
                    {
                        data[i][4] = Convert.ToDouble(0);
                        data[i][5] = Convert.ToDouble(0);
                        data[i][6] = Convert.ToDouble(1);
                    }
                    else if (tmp[tmp.Length - 1] == "Iris-versicolor")
                    {
                        data[i][4] = Convert.ToDouble(0);
                        data[i][5] = Convert.ToDouble(1);
                        data[i][6] = Convert.ToDouble(0);
                    }
                    else if (tmp[tmp.Length - 1] == "Iris-virginica")
                    {
                        data[i][4] = Convert.ToDouble(1);
                        data[i][5] = Convert.ToDouble(0);
                        data[i][6] = Convert.ToDouble(0);
                    }
                }
            }
            return data;
        }

        public static double[][] Shuffle(double[][] data)
        {
            Random random = new Random();
            double[][] shuffeled = new double[data.GetUpperBound(0)][];
            List<double> usedPositions = new List<double>();
            int number;
            for (int i = 0; i < data.GetUpperBound(0); i++)
            {
                number = random.Next(0, data.GetUpperBound(0));
                if (!usedPositions.Contains(number))
                {
                    shuffeled[i] = data[number];
                    usedPositions.Add(number);
                }
                else
                    i--;
            }
            return shuffeled;
        }

        public static void Iris(Network network, double[] inputData)
        {
            network.PushInputValues(inputData);
            Console.Write("Input data: ");
            for (int i = 0; i < inputData.Length; i++)
                Console.Write(inputData[i] + " ");

            List<double> result = network.CalculateNetwork();
            Console.Write("\nType: ");
            double undefined = 0;
            foreach (var r in result)
                undefined += Math.Abs(r);
            if(undefined > 1.25 || undefined < 0.75)
                Console.WriteLine("undefined");
            else
            {
                string[] iris = { "Iris-virginica", "Iris-versicolor", "Iris-setosa" };
                Console.Write(iris[result.IndexOf(result.Max())] + "\n\n");
            }
        }


    }
}
