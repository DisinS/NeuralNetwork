﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    class Network
    {
        static double coefficient = 0.5;
        internal List<Layer> Layers;
        internal double[][] ExpectedResult;
        double[][] differences;

        public Network(int inputLayerCount, int numberOfHiddenLayers, int hiddenLayerCount, int outputLayerCount)
        {
            if(inputLayerCount < 1 || numberOfHiddenLayers < 1 || hiddenLayerCount < 1 || outputLayerCount < 1)
                throw new Exception("Invalid Network Parameters");

            Layers = new List<Layer>();
            AddInputLayer(inputLayerCount);
            for (int i = 0; i < numberOfHiddenLayers; i++)
                AddHiddenLayer(hiddenLayerCount);
            AddOutputLayer(outputLayerCount);

            differences = new double[Layers.Count][];
            for (int i = 1; i < Layers.Count; i++)
                differences[i] = new double[Layers[i].Neurons.Count];
        }
        #region AddLayer
        private void AddInputLayer(int inputLayerCount)
        {
            Layer inputLayer = new Layer(inputLayerCount);
            foreach (Neuron neuron in inputLayer.Neurons)
                neuron.AddFirstInputSynapse(0);
            Layers.Add(inputLayer);
        }
        private void AddHiddenLayer(int hiddenLayerCount)
        {
            Layer hiddenLayer = new Layer(hiddenLayerCount);
            Layers[Layers.Count - 1].ConnectLayers(hiddenLayer);
            Layers.Add(hiddenLayer);
        }
        private void AddOutputLayer(int outputLayerCount) => AddHiddenLayer(outputLayerCount);
        #endregion
        #region PushValue
        public void PushInputValues(double[] inputValues)
        {
            if(inputValues.Length != Layers[0].Neurons.Count())
                throw new Exception("Invalid Input Size");

            for (int i = 0; i < inputValues.Length; i++)
                Layers[0].Neurons[i].PushValueOnInput(inputValues[i]);
        }
        public void PushExpectedValues(double[][] expectedValues)
        {
            if (expectedValues[0].Length != Layers[Layers.Count - 1].Neurons.Count())
                throw new Exception("Invalid Expected Output Size");
            ExpectedResult = expectedValues;
        }
        #endregion
        
        public void Train(double[][] inputs, double maxError)
        {
            Console.WriteLine("\n Training...");
            double totalError = double.MaxValue;
            while (totalError / inputs.Length > maxError)
            {
                totalError = 0;
                List<double> outputs = new List<double>();
                for (int j = 0; j < inputs.Length; j++)
                {
                    PushInputValues(inputs[j]);
                    outputs = CalculateNetwork();
                    ChangeWeights(outputs, j);
                    totalError += CalculateTotalError(outputs, j);
                }
                //Console.WriteLine("Actual error: " + (totalError/inputs.Length).ToString());  // testing error
            }
            Console.WriteLine("The Network is learned! Average error: " + (Math.Round(totalError / inputs.Length, 5)).ToString() + "\n");
        }
        #region Calculates
        public List<double> CalculateNetwork()
        {
            List<double> outputValues = new List<double>();
            foreach (Layer layer in Layers)
                layer.CalculateLayerOutput();
            foreach (Neuron neuron in Layers[Layers.Count - 1].Neurons)
                outputValues.Add(neuron.OutputValue);
            return outputValues;
        }
        private void CalculateDiffrences(List<double> outputs, int row)
        {
            for (int i = 0; i < Layers[Layers.Count - 1].Neurons.Count; i++)
                differences[Layers.Count - 1][i] = (ExpectedResult[row][i] - outputs[i]) 
                    * Functions.CurrentFunctionDifferential(Layers[Layers.Count - 1].Neurons[i].InputValue);
            for (int i = Layers.Count - 2; i > 0; i--)
            {
                for (int j = 0; j < Layers[i].Neurons.Count; j++)
                {
                    differences[i][j] = 0;
                    for (int k = 0; k < Layers[i + 1].Neurons.Count; k++)
                        differences[i][j] += differences[i + 1][k] * Layers[i + 1].Neurons[k].Inputs[j].Weight;
                    differences[i][j] *= Functions.CurrentFunctionDifferential(Layers[i].Neurons[j].InputValue);
                }
            }
        }
        private double CalculateTotalError(List<double> outputs, int row)
        {
            double totalError = 0;
            foreach (double output in outputs)
                totalError += Math.Pow(output - ExpectedResult[row][outputs.IndexOf(output)], 2);
            return totalError;
        }
        #endregion
        private void ChangeWeights(List<double> outputs, int row)
        {
            CalculateDiffrences(outputs, row);
            for (int i = Layers.Count - 1; i > 0; i--)
                for (int j = 0; j < Layers[i].Neurons.Count; j++)
                    for (int k = 0; k < Layers[i - 1].Neurons.Count; k++)
                        Layers[i].Neurons[j].Inputs[k].UpdateWeight(
                            coefficient * 2 * differences[i][j] * Layers[i - 1].Neurons[k].OutputValue);
        }



    }
}
