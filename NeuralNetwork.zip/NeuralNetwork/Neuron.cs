﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    class Neuron
    {
        public List<Synapse> Inputs { get; set; }
        public List<Synapse> Outputs { get; set; }
        public double InputValue { get; set; }
        public double OutputValue { get; set; }

        public Neuron()
        {
            Inputs = new List<Synapse>();
            Outputs = new List<Synapse>();
        }

        public void ConnectNeurons(Neuron outputNeuron)
        {
            Synapse synapse = new Synapse(this, outputNeuron);
            Outputs.Add(synapse);
            outputNeuron.Inputs.Add(synapse);
        }
        public void AddFirstInputSynapse(double input)
        {
            Synapse synapse = new Synapse(this, input);
            Inputs.Add(synapse);            
        }
        public void CalculateValues()
        {
            double input = 0;
            foreach (Synapse synapse in Inputs)
                input += synapse.GetOutput();
            InputValue = input;
            OutputValue = Functions.CurrentFunction(InputValue);
        }
        public void PushValueOnInput(double input) =>
            Inputs[0].OutputValue = input;
        


    }
}
