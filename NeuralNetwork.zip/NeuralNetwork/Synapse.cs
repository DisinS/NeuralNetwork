﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    class Synapse
    {
        static Random tmpRandom = new Random();
        internal Neuron FromNeuron;
        internal Neuron ToNeuron;
        public double Weight { get; set; }
        public double OutputValue { get; set; }

        public Synapse(Neuron fromNeuron, Neuron toNeuron)
        {
            FromNeuron = fromNeuron;
            ToNeuron = toNeuron;                        
            Weight = tmpRandom.NextDouble() - 0.5;
        }
        public Synapse(Neuron toNeuron, double firstOutputValue) //FirstInputSynapse
        {
            ToNeuron = toNeuron;
            OutputValue = firstOutputValue;
            Weight = 1;
        }
        
        public double GetOutput() =>
            FromNeuron == null ? OutputValue : FromNeuron.OutputValue * Weight;

        public void UpdateWeight(double delta) =>
            Weight += delta;
        
    }
}
