﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    class Program
    {
        static void Main(string[] args)
        {
            double[][] data = Data.LoadIris();
            data = Data.Shuffle(data);

            int limit = data.Length - 10;//the rest will check how program works
            double[][] traingValues = new double[limit][];
            double[][] expectedValues = new double[limit][]; 
            for (int i = 0; i < limit; i++)
            {
                traingValues[i] = new double[4];
                expectedValues[i] = new double[3];
                for (int j = 0; j < 4; j++)
                    traingValues[i][j] = data[i][j];
                for (int j = 4; j < 7; j++)
                    expectedValues[i][j - 4] = data[i][j];
            }

            Network network = new Network(4, 5, 4, 3);
            network.PushExpectedValues(expectedValues);
            network.Train(traingValues, 0.03);

            double[][] test = new double[data.Length - limit][];
            for (int i = 0; i < test.Length; i++)
            {
                test[i] = new double[4];
                for (int j = 0; j < 4; j++)
                    test[i][j] = data[i + limit][j];
                Data.Iris(network, test[i]);
            }

            Console.ReadKey();
        }
    }
}
