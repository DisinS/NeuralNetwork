﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    class Layer
    {
        public List<Neuron> Neurons { get; set; }

        public Layer(int numberOfNeurons)
        {
            Neurons = new List<Neuron>();
            for (int i = 0; i < numberOfNeurons; i++)
                Neurons.Add(new Neuron());
        }

        public void ConnectLayers(Layer outputLayer)
        {
            foreach (Neuron inputNeuron in Neurons)
                foreach (Neuron outputNeuron in outputLayer.Neurons)
                    inputNeuron.ConnectNeurons(outputNeuron);   
        }
        public void CalculateLayerOutput()
        {
            foreach (Neuron neuron in Neurons)
                neuron.CalculateValues();
        }

    }
}
