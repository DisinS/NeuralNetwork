﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    class Functions
    {
        private static double alpha = 0.5;
        public static double CurrentFunction(double input) => BipolarLinearFunction(input);//any other function
        public static double CurrentFunctionDifferential(double input) => BipolarDifferential(input);// change with change of function

        //BIPOLAR FUNCTION
        public static double BipolarLinearFunction(double input) => //active function
            (1 - Math.Exp(-alpha * input)) / (1 + Math.Exp(-alpha * input));
        public static double BipolarDifferential(double input) => //differential of active function
            (2 * alpha * Math.Exp(-alpha * input)) / (Math.Pow(1 + Math.Exp(-alpha * input), 2));


    }
}
